<?php get_header(); ?>

	<main class="site-main">

		<?php get_template_part( 'parts/content/content', 'none' ); ?>

	</main>

<?php get_footer();
