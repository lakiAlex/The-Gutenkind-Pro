<?php get_header(); ?>

    <main class="site-main">

        <?php get_template_part( 'parts/archive/archive', 'page' ); ?>

    </main>

<?php get_footer();
