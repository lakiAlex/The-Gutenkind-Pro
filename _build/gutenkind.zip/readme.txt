# Gutenkind

**Contributors:** Vossen Themes
**Requires at least:** WordPress 4.9.6
**Tested up to:** WordPress 5.x
**License:** GPLv2 or later
**License URI:** http://www.gnu.org/licenses/gpl-2.0.html
**Tags:** one-column, flexible-header, accessibility-ready, custom-colors, custom-menu, custom-logo, editor-style, featured-images, footer-widgets, rtl-language-support, sticky-post, theme-options, threaded-comments, translation-ready
