
	<?php get_template_part( 'parts/footer/footer', 'v1' ); ?>

</div>

<?php wp_footer(); ?>

</body>
</html>
